/*
 * This metadata is used by the Saleslogix platform.  Do not remove.
<snippetHeader xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" id="17a243ce-b84a-4b12-a7b6-a0a2a719719e">
 <assembly>Sage.SnippetLibrary.CSharp</assembly>
 <name>OnCreateStep</name>
 <references>
  <reference>
   <assemblyName>Sage.Entity.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\interfaces\bin\Sage.Entity.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Form.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\formInterfaces\bin\Sage.Form.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Platform.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\assemblies\Sage.Platform.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.SalesLogix.API.dll</assemblyName>
  </reference>
 </references>
</snippetHeader>
*/


#region Usings
using System;
using Sage.Entity.Interfaces;
using Sage.Form.Interfaces;
using Sage.SalesLogix.API;
#endregion Usings

namespace Sage.BusinessRules.CodeSnippets
{
    public static partial class NotificationEventBusinessRules
    {
        public static void OnCreateStep( INotificationEvent notificationevent)
        {
			notificationevent.Enabled = true;
			notificationevent.DynamicNotification = false;
			notificationevent.CheckIntervalType = "Timer";
			notificationevent.CheckInterval = 60;
			notificationevent.TimeOfDayToCheck = Convert.ToDateTime("19700929 04:23PM");
			notificationevent.LastChecked = DateTime.UtcNow;
			notificationevent.NextTimeToCheck = DateTime.UtcNow;
			notificationevent.DaysOfWeek = "Mon,Tues,Wed,Thurs,Fri";
        }
    }
}