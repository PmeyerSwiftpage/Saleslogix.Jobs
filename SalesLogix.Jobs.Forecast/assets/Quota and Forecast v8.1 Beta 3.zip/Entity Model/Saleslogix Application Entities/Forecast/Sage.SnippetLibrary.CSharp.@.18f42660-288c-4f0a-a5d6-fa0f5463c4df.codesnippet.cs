/*
 * This metadata is used by the Sage platform.  Do not remove.
<snippetHeader xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" id="18f42660-288c-4f0a-a5d6-fa0f5463c4df">
 <assembly>Sage.SnippetLibrary.CSharp</assembly>
 <name>PeriodPipelineAmtStep</name>
 <references>
  <reference>
   <assemblyName>Sage.Entity.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\interfaces\bin\Sage.Entity.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Form.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\formInterfaces\bin\Sage.Form.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Platform.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\assemblies\Sage.Platform.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.SalesLogix.API.dll</assemblyName>
  </reference>
 </references>
</snippetHeader>
*/


#region Usings
using System;
using Sage.Entity.Interfaces;
using Sage.Form.Interfaces;
using Sage.SalesLogix.API;
#endregion Usings

namespace Sage.BusinessRules.CodeSnippets
{
	public static partial class ForecastBusinessRules
	{
		public static void PeriodPipelineAmtStep(IForecast forecast, String amtLevel, out Double result)
		{
			result = 0;
			double min = 0;
			double avg = 0;
			double max = 0;

			foreach (IForecastOpportunity fo in forecast.ForecastOpportunities)
			{
				// Do the calculations
				if (fo.OpportunityStatus != _closedWon && fo.OpportunityStatus != _closedLost)
				{
					if (fo.MinPotential.HasValue)
					{
						min += fo.MinPotential.Value;
					}
					
					if (fo.MaxPotential.HasValue)
					{
						max += fo.MaxPotential.Value;
					}
					
					if (fo.MinPotential.HasValue && fo.MaxPotential.HasValue)
					{
						avg += (fo.MinPotential.Value + fo.MaxPotential.Value) /2;
					}
				}
			}
			
			// determine which value to return
			switch (amtLevel.ToLower())
			{
				case "min":
					result = min;
					break;
				case "avg":
					result = avg;
					break;
				case "max":
					result = max;
					break;
			}
		}
	}
}
