/*
 * This metadata is used by the Saleslogix platform.  Do not remove.
<snippetHeader xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" id="73ad658e-ed96-4eed-ae13-31e65a28216c">
 <assembly>Sage.SnippetLibrary.CSharp</assembly>
 <name>PullInOpportunitiesStep</name>
 <references>
  <reference>
   <assemblyName>Sage.Entity.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\interfaces\bin\Sage.Entity.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Form.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\formInterfaces\bin\Sage.Form.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Platform.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\assemblies\Sage.Platform.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.SalesLogix.API.dll</assemblyName>
  </reference>
 </references>
</snippetHeader>
*/


#region Usings
using System;
using Sage.Entity.Interfaces;
using Sage.Form.Interfaces;
using Sage.SalesLogix.API;
#endregion Usings

namespace Sage.BusinessRules.CodeSnippets
{
	using NHibernate;
	using Sage.Platform.Orm;
	using Sage.Platform.Orm.Interfaces;
	using System.Collections.Generic;

	public static partial class ForecastBusinessRules
	{
		const string _closedWon = "Closed - Won";
		const string _closedLost = "Closed - Lost";
		const string _open = "Open";
		
		public static void PullInOpportunitiesStep(IForecast forecast)
		{
			DateTime beginDate = forecast.BeginDate.Value.Date;
			DateTime endDate = EndOfDay(forecast.EndDate.Value);
			
			// Add everything to list if it contains nothing
			if (forecast.ForecastOpportunities.Count == 0)
			{
				generateForecastOpportunityList(forecast);				
			}
			else
			{
				// Update current list of items (update or remove)
				System.Collections.Generic.List<string> lRemove = new System.Collections.Generic.List<string>();
				DateTime? oppDate;
				using (ISession session = new SessionScopeWrapper(true))
				{
					IList<Sage.Entity.Interfaces.IForecastOpportunity> query = session.QueryOver<Sage.Entity.Interfaces.IForecastOpportunity>()
						.Where(x => x.Forecast == forecast)
						.List<Sage.Entity.Interfaces.IForecastOpportunity>();
					
					foreach (IForecastOpportunity fo in query)
					{					
						if (fo.Opportunity == null)
						{
							// Opportunity doesn't exist
							lRemove.Add(fo.Id.ToString());
						}
						else if (fo.Opportunity.AccountManager != fo.Forecast.AssignedTo)
						{
							// Account Manager does not match
							lRemove.Add(fo.Id.ToString());
						}
						else if (fo.Opportunity.Status == _closedLost)
						{
							// Opportunity was Lost
							lRemove.Add(fo.Id.ToString());
						}
						else if (fo.Opportunity.AddToForecast == false)
						{
							// Opportunity not checked to Add to Forecast
							lRemove.Add(fo.Id.ToString());
						}
						else
						{
							oppDate = new DateTime(1970, 1, 1);
							switch (fo.Opportunity.Status)
							{
								case _open:
									if (fo.Opportunity.EstimatedClose.HasValue)
									{
										oppDate = fo.Opportunity.EstimatedClose;
									}
									break;
								case _closedWon:
									if (fo.Opportunity.ActualClose.HasValue)
									{
										oppDate = fo.Opportunity.ActualClose;
									}
									break;
							}
							if (oppDate < beginDate || oppDate > endDate)
							{
								// Opportunity falls outside of the Period
								lRemove.Add(fo.Id.ToString());
							}
							else
							{
								updateForecastOpportunity(fo);
							}
						}
					}
				}

				// Remove any Forecast Opportunity that made it into the removal list.
				foreach (string id in lRemove)
				{
					IForecastOpportunity fo = Sage.Platform.EntityFactory.GetById<IForecastOpportunity>(id);
					if (fo != null)
					{
						forecast.ForecastOpportunities.Remove(fo);
						fo.Delete();
					}
				}

				// Add Open & Won Opportunities, refresh existing opps
				using (ISession session = new SessionScopeWrapper(true))
				{
					IList<Sage.Entity.Interfaces.IOpportunity> query = session.QueryOver<Sage.Entity.Interfaces.IOpportunity>()
						.Where(x => x.AddToForecast == true && 
						x.AccountManager == forecast.AssignedTo && 
						(x.Status == _open || x.Status == _closedWon) && 
						(x.EstimatedClose >= beginDate && x.EstimatedClose <= endDate))
						.List<Sage.Entity.Interfaces.IOpportunity>();

					foreach (Sage.Entity.Interfaces.IOpportunity opp in query)
					{
						bool bFound = false;
						foreach (IForecastOpportunity fo in forecast.ForecastOpportunities)
						{
							if (String.Compare(fo.Opportunity.Id.ToString(),opp.Id.ToString()) == 0)
							{
								bFound = true;
								break;
							}
						}
						if (!bFound)
						{
							// Insert
							IForecastOpportunity fo = Sage.Platform.EntityFactory.Create<IForecastOpportunity>();
							fo.Forecast = forecast;
							fo.Opportunity = opp;
							updateForecastOpportunity(fo);
							forecast.ForecastOpportunities.Add(fo);
						}
					}
				}
				forecast.Save();
			}
		}

		public static DateTime EndOfDay(DateTime d)
		{
			return (d.Date.AddHours(23).AddMinutes(59).AddSeconds(59));
		}
		
		private static void generateForecastOpportunityList(IForecast forecast)
		{
			DateTime beginDate = forecast.BeginDate.Value.Date;
			DateTime endDate = EndOfDay(forecast.EndDate.Value);

			// Get Closed-Won & Open Opportunities within the Date Range of the Forecast
			using (ISession session = new SessionScopeWrapper(true))
			{
				IList<Sage.Entity.Interfaces.IOpportunity> query = session.QueryOver<Sage.Entity.Interfaces.IOpportunity>()
					.Where(x => x.AddToForecast == true && 
					x.AccountManager == forecast.AssignedTo &&
					((x.Status == _closedWon && (x.ActualClose >= beginDate && x.ActualClose <= endDate)) ||
					(x.Status == _open && (x.EstimatedClose >= beginDate && x.EstimatedClose <= endDate))))
					.List<Sage.Entity.Interfaces.IOpportunity>();
				
				foreach (Sage.Entity.Interfaces.IOpportunity opp in query)
				{
					Sage.Entity.Interfaces.IForecastOpportunity fo = Sage.Platform.EntityFactory.Create<IForecastOpportunity>();
					fo.Forecast = forecast;
					fo.Opportunity = opp;
					updateForecastOpportunity(fo);
					forecast.ForecastOpportunities.Add(fo);
				}
			}
			forecast.Save();
		}
		
		private static void updateForecastOpportunity(IForecastOpportunity fo)
		{
			fo.OpportunityStatus = fo.Opportunity.Status;
			fo.CloseProbability = fo.Opportunity.CloseProbability;
		
			switch (fo.OpportunityStatus)
			{
				case _closedWon:
					fo.CloseProbability = 100;
					fo.OpportunityCloseDate = fo.Opportunity.ActualClose.Value;				
					fo.MinPotential = fo.MaxPotential = Convert.ToDouble(fo.Opportunity.ActualAmount);
					break;
				case _open:
					fo.OpportunityCloseDate = fo.Opportunity.EstimatedClose;				
					fo.MaxPotential = Convert.ToDouble(fo.Opportunity.SalesPotential);
					fo.MinPotential = Convert.ToDouble(fo.MaxPotential) * (Convert.ToDouble(fo.CloseProbability)/100);
					break;
			}
		}
	}
}
