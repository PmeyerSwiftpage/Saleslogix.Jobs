/*
 * This metadata is used by the Sage platform.  Do not remove.
<snippetHeader xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" id="a51b2e24-5e80-4022-994c-2c7773dbf0ad">
 <assembly>Sage.SnippetLibrary.CSharp</assembly>
 <name>TakeSnapshotStep</name>
 <references>
  <reference>
   <assemblyName>Sage.Entity.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\interfaces\bin\Sage.Entity.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Form.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\formInterfaces\bin\Sage.Form.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Platform.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\assemblies\Sage.Platform.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.SalesLogix.API.dll</assemblyName>
  </reference>
 </references>
</snippetHeader>
*/


#region Usings
using System;
using Sage.Entity.Interfaces;
using Sage.Form.Interfaces;
using Sage.SalesLogix.API;
#endregion Usings

namespace Sage.BusinessRules.CodeSnippets
{
	public static partial class ForecastBusinessRules
	{
		public static void TakeSnapshotStep(IForecast forecast, out Boolean result)
		{
			result = false;
			
			Sage.Entity.Interfaces.IForecastSnapshot snapshot = Sage.Platform.EntityFactory.Create<Sage.Entity.Interfaces.IForecastSnapshot>();
			
			snapshot.Forecast = forecast;
			snapshot.SnapshotDate = DateTime.UtcNow;
			snapshot.ForecastAmount = forecast.Amount;
			snapshot.ClosedWonAmt = Convert.ToDecimal(forecast.PeriodClosedWonAmt());
			snapshot.QuotaAmt = Convert.ToDecimal(forecast.PeriodQuotaAmt());
			snapshot.Description = String.Format("{0} - {1}", snapshot.SnapshotDate.Value.Date.ToShortDateString(), forecast.Description);
			
			forecast.ForecastSnapshots.Add(snapshot);
			
			snapshot.Save();
			
			result = true;
		}
	}
}
