﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;

namespace slxCustom
{
    /// <summary>
    /// Summary description for CustomHelpers
    /// </summary>
    public class Date
    {
        public static DateTime? FirstDayofMonth(DateTime? _date)
        {
            return _date.Value.AddDays(1 - _date.Value.Day);
        }

        public static DateTime? FirstDayofMonth()
        {
            return FirstDayofMonth(DateTime.UtcNow);
        }

        public static DateTime? LastDayofMonth(DateTime? _date)
        {
            return _date.Value.AddMonths(1).AddDays(-1);
        }

        public static DateTime? LastDayofMonth()
        {
            return LastDayofMonth(DateTime.UtcNow);
        }

        public static string ToMonthName(DateTime? _date)
        {
            return CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(_date.Value.Month);
        }

        public static string ToShortMonthName(DateTime? _date)
        {
            return CultureInfo.CurrentCulture.DateTimeFormat.GetAbbreviatedMonthName(_date.Value.Month);
        }
		
		public static string MonthName(int _month = 1)
		{
			if (_month < 1 || _month > 12)
			{
				 _month = 1;
			}
			return CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(_month);
		}
    }
}