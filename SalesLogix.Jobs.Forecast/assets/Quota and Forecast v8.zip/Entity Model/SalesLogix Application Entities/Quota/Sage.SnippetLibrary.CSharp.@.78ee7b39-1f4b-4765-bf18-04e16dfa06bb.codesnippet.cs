/*
 * This metadata is used by the Sage platform.  Do not remove.
<snippetHeader xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" id="78ee7b39-1f4b-4765-bf18-04e16dfa06bb">
 <assembly>Sage.SnippetLibrary.CSharp</assembly>
 <name>CopyQuotaStep</name>
 <references>
  <reference>
   <assemblyName>Sage.Entity.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\interfaces\bin\Sage.Entity.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Form.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\formInterfaces\bin\Sage.Form.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Platform.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\assemblies\Sage.Platform.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.SalesLogix.API.dll</assemblyName>
  </reference>
 </references>
</snippetHeader>
*/


#region Usings
using System;
using Sage.Entity.Interfaces;
using Sage.Form.Interfaces;
using Sage.SalesLogix.API;
#endregion Usings

namespace Sage.BusinessRules.CodeSnippets
{
	using NHibernate;
	using Sage.Platform.Orm;
	using Sage.Platform.Orm.Interfaces;
	using System.Collections.Generic;

	public static partial class QuotaBusinessRules
	{
		public static void CopyStep(IQuota quota, IQuota oldQuota, String requestId)
		{
			// Clone Quota for future periods
			// Check fiscal calendar to see how long a period lasts (Month, Quarter, Semi-Annual, Year)
			using (ISession session = new SessionScopeWrapper(true)) {
				Sage.Entity.Interfaces.ICustomSetting setting = session.QueryOver<Sage.Entity.Interfaces.ICustomSetting>().Where(x => x.Category == "Fiscal" && x.Description == "QutoaAndForecastBy").SingleOrDefault();

				int period = 1;
				if (!String.IsNullOrEmpty(setting.DataValue)) {
					period = Convert.ToInt32(setting.DataValue);
				}

				DateTime beginDate = FirstDayofMonth(oldQuota.EndDate.Value.AddDays(1));
				DateTime endDate = LastDayofMonth(beginDate.AddMonths(1 * (period - 1)));

				quota.BeginDate = beginDate;
				quota.EndDate = endDate;
				quota.Amount = oldQuota.Amount;
				quota.AssignedTo = oldQuota.AssignedTo;
				quota.IsActive = true;
				quota.Description = quota.GetFormattedDescription();
			}
		}

		public static DateTime FirstDayofMonth(DateTime _date)
		{
			return _date.AddDays(1 - _date.Day);
		}

		public static DateTime LastDayofMonth(DateTime _date)
		{
			return _date.AddMonths(1).AddDays(-1);
		}
	}
}
