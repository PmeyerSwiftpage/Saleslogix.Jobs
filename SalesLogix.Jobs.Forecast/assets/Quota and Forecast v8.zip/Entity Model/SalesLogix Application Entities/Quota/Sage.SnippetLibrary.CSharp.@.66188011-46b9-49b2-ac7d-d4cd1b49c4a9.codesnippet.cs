/*
 * This metadata is used by the Sage platform.  Do not remove.
<snippetHeader xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" id="66188011-46b9-49b2-ac7d-d4cd1b49c4a9">
 <assembly>Sage.SnippetLibrary.CSharp</assembly>
 <name>GetFormattedDescriptionStep</name>
 <references>
  <reference>
   <assemblyName>Sage.Entity.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\interfaces\bin\Sage.Entity.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Form.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\formInterfaces\bin\Sage.Form.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Platform.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\assemblies\Sage.Platform.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.SalesLogix.API.dll</assemblyName>
  </reference>
 </references>
</snippetHeader>
*/


#region Usings
using System;
using Sage.Entity.Interfaces;
using Sage.Form.Interfaces;
using Sage.SalesLogix.API;
#endregion Usings

namespace Sage.BusinessRules.CodeSnippets
{
	using System.Globalization;
	
    public static partial class QuotaBusinessRules
    {
        public static void GetFormattedDescriptionStep( IQuota quota, out String result)
        {
			string user = "Unknown";
			string month = "Unknown";
			string year = "Unknown";
			
			if (quota.AssignedTo != null)
				user = quota.AssignedTo.UserInfo.NameLF.Trim().TrimEnd(',');
			
			if (quota.BeginDate != null)
			{
				month = CultureInfo.CurrentCulture.DateTimeFormat.GetAbbreviatedMonthName(quota.BeginDate.Value.Month);
				year = quota.BeginDate.Value.Year.ToString();
			}
			
			result = String.Format("{0}: {1}, {2}", user, month, year);
			
        }
    }
}
