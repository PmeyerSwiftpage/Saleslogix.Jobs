/*
 * This metadata is used by the Sage platform.  Do not remove.
<snippetHeader xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" id="d64b4f7a-c1a2-4102-afe5-56894ebc286f">
 <assembly>Sage.SnippetLibrary.CSharp</assembly>
 <name>GetFormattedDescriptionStep</name>
 <references>
  <reference>
   <assemblyName>Sage.Entity.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\interfaces\bin\Sage.Entity.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Form.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\formInterfaces\bin\Sage.Form.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Platform.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\assemblies\Sage.Platform.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.SalesLogix.API.dll</assemblyName>
  </reference>
 </references>
</snippetHeader>
*/


#region Usings
using System;
using Sage.Entity.Interfaces;
using Sage.Form.Interfaces;
using Sage.SalesLogix.API;
#endregion Usings

namespace Sage.BusinessRules.CodeSnippets
{
    public static partial class ForecastBusinessRules
    {
        public static void GetFormattedDescriptionStep( IForecast forecast, out String result)
        {
			result = null;
			
			if (forecast.AssignedTo != null)
			{
				result = String.Format("{0}: ", forecast.AssignedTo.UserInfo.NameLF);
			}
			
			if (forecast.BeginDate.Value.Month == forecast.EndDate.Value.Month)
			{
				result += String.Format("{0} {1}", 
				System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(forecast.BeginDate.Value.Month), forecast.BeginDate.Value.Year);
			}
			else
			{
				result += String.Format("{0} {1} - {2} {3}",
            		System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(forecast.BeginDate.Value.Month), forecast.BeginDate.Value.Year,
            		System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(forecast.EndDate.Value.Month), forecast.EndDate.Value.Year);				
			}
		}
    }
}