/*
 * This metadata is used by the Saleslogix platform.  Do not remove.
<snippetHeader xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" id="5fe30c3d-ce9c-4c79-b42b-0a750e15ddd5">
 <assembly>Sage.SnippetLibrary.CSharp</assembly>
 <name>PurgeOldDeliveryItemsStep</name>
 <references>
  <reference>
   <assemblyName>Sage.Entity.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\interfaces\bin\Sage.Entity.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Form.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\formInterfaces\bin\Sage.Form.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Platform.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\assemblies\Sage.Platform.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.SalesLogix.API.dll</assemblyName>
  </reference>
 </references>
</snippetHeader>
*/


#region Usings
using System;
using Sage.Entity.Interfaces;
using Sage.Form.Interfaces;
using Sage.SalesLogix.API;
#endregion Usings

namespace Sage.BusinessRules.CodeSnippets
{
	using NHibernate;
	using Sage.Platform.Orm;
	using Sage.Platform.Orm.Interfaces;
	using System.Collections.Generic;

    public static partial class DeliverySystemBusinessRules
    {
        public static void PurgeOldDeliveryItemsStep( IDeliverySystem deliverysystem)
        {
			if (deliverysystem.PurgeAfterDays == null)
			{
				return;
			}
			else if (deliverysystem.PurgeAfterDays == 0)
			{
				return;
			}			
			DateTime purgeDate = DateTime.Now.Date.AddDays(0-(int)deliverysystem.PurgeAfterDays);
			
			using (ISession session = new SessionScopeWrapper(true))
			{
				IList<IDeliveryItem> deliveryItems = session.QueryOver<IDeliveryItem>().Where(x => x.DeliverySystem == deliverysystem && x.ModifyDate <= purgeDate).List<IDeliveryItem>();
				
				foreach(IDeliveryItem di in deliveryItems)
				{
					di.Delete();
				}
			}
        }
    }
}
