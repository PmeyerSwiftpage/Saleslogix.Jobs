/*
 * This metadata is used by the Saleslogix platform.  Do not remove.
<snippetHeader xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" id="62954ccd-72a4-4200-8a53-e49fbab4a584">
 <assembly>Sage.SnippetLibrary.CSharp</assembly>
 <name>OnCreateStep</name>
 <references>
  <reference>
   <assemblyName>Sage.Entity.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\interfaces\bin\Sage.Entity.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Form.Interfaces.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\formInterfaces\bin\Sage.Form.Interfaces.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.Platform.dll</assemblyName>
   <hintPath>%BASEBUILDPATH%\assemblies\Sage.Platform.dll</hintPath>
  </reference>
  <reference>
   <assemblyName>Sage.SalesLogix.API.dll</assemblyName>
  </reference>
 </references>
</snippetHeader>
*/


#region Usings
using System;
using Sage.Entity.Interfaces;
using Sage.Form.Interfaces;
using Sage.SalesLogix.API;
#endregion Usings

namespace Sage.BusinessRules.CodeSnippets
{
    public static partial class DeliverySystemBusinessRules
    {
        public static void OnCreateStep( IDeliverySystem deliverysystem)
        {
			// Set defaults 
            deliverysystem.SmtpEnableSsl = true;
			deliverysystem.SmtpIsBodyHtml = true;
			deliverysystem.SystemType = "SMTP";
			deliverysystem.SmtpPort = 25;
			deliverysystem.PurgeAfterDays = 30;
        }
    }
}